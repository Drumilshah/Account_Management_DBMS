public class Item{
	String item;
	int qty;
	double amount;
	
	public Item(String item,double amount,int qty) {
		this.item = item;
		this.qty = qty;
		this.amount = amount;
	}
}