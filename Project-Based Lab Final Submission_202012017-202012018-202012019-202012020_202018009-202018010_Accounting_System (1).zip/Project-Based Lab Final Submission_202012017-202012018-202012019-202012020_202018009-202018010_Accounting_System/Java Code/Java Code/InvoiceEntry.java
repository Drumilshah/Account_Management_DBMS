import java.util.ArrayList;
import java.util.Iterator;
import java.util.Date;

public class InvoiceEntry{
	Date date;
	String accountName;
	int invoiceId;
	ArrayList<Item> items;
	
	public InvoiceEntry() {
		this.items = new ArrayList<Item>();
		
	}
	
	public InvoiceEntry(int invoiceId, Date date, String accountName) {
		this.invoiceId = invoiceId;
		this.date = date;
		this.accountName = accountName;
		this.items = new ArrayList<Item>();
		
	}
	
	/*public String toString() {
		StringBuilder output = new StringBuilder();
		
		output.append("\n\nDate: " + this.date);
		
		Iterator<Account> it = this.drAccounts.iterator();
		
		while(it.hasNext())
			output.append("\nDr.\t" + it.next());
		
		it = this.crAccounts.iterator();
		while(it.hasNext())
			output.append("\n\t\tTo " + it.next());

		
		output.append("\n(" + this.description + ")");
		return output.toString();
	}*/
}