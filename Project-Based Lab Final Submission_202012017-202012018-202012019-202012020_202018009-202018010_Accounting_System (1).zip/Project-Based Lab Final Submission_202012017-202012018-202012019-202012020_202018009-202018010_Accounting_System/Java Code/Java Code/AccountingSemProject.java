import java.sql.*;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.text.SimpleDateFormat;
import java.util.Date;


public class AccountingSemProject {
	static String USERNAME = "YOUR USERNAME";
	static String PASSWORD = "YOUR PASSWORD";
	static String DATABASE = "DATABASE NAME";
	static Connection conn;
	
	public static void Query13() throws SQLException {
		//Query Conditions
		String company = "Myntra";
		String from = "01-04-2019";
		String to = "31-03-2020";
		
		Statement stmt = conn.createStatement();
		stmt = conn.createStatement();

		String query = "\n"
				+ "Select Ft.TransactionNumber, Ft.TransactionDate,A.accountName,ABS(F.Amount) as \"Transaction Amount\", (\n"
				+ "	Case \n"
				+ "		When AG.Header = True AND F.Amount > 0 THEN True\n"
				+ "	 	When AG.Header = True AND F.Amount < 0 THEN False\n"
				+ "		When AG.Header = False AND F.Amount > 0 THEN False\n"
				+ "		When AG.Header = False AND F.Amount < 0 THEN True\n"
				+ "	END\n"
				+ ") AS \"Header\", FT.TransactionDescription\n"
				+ "From FinancialTransaction as FT JOIN FinancialTransactionEntry as F ON (FT.TransactionNumber =\n"
				+ "F.TransactionNumber)\n"
				+ "JOIN Account as A ON (F.accountId = A.accountId)\n"
				+ "JOIN AccountGroup as AG ON (AG.AccountGroupId = A.AccountGroupId)\n"
				+ "JOIN Company as C ON (C.CompanyId = AG.CompanyId)\n"
				+ "Where C.CompanyName = '"+ company +"' AND Ft.TransactionDate BETWEEN '"+ from +"' AND '"+ to +"'\n"
				+ "Order By FT.TransactionDate, Ft.TransactionNumber;";
		
		System.out.println(query);

		ResultSet rs = stmt.executeQuery(query);

		ArrayList<JournalEntry> entries = new ArrayList<JournalEntry>();
		JournalEntry entry = new JournalEntry();
		int previousTransaction = 0;

		while (rs.next()) {
			int id = rs.getInt("TransactionNumber");
			
			if(previousTransaction != id) {
				if(previousTransaction!=0)
					entries.add(entry);
				
				entry = new JournalEntry(rs.getDate("TransactionDate"), rs.getString("TransactionDescription"));
				previousTransaction = id;
			}
			
			if(rs.getBoolean("Header")) 
				entry.drAccounts.add( new Account(rs.getString("AccountName"), rs.getDouble("Transaction Amount")));
			else
				entry.crAccounts.add( new Account(rs.getString("AccountName"), rs.getDouble("Transaction Amount")));
			
		}
		rs.close();
		stmt.close();
		
		
		
//		Iterator<JournalEntry> it = entries.iterator();
//		
//		while(it.hasNext()) {
//			System.out.println(it.next() + "\n\n");
//		}
		
		CreateHTML f1 = new CreateHTML("./Reports/Journal.html");
		f1.createJournal("ABC Ltd.", entries);
	}
	
	
	public static void Query14() throws SQLException, Exception{
		
		String dateFormat = "dd-MM-yyyy";

		//Query Conditions
		String company = "Myntra";
		String accountName = "Banks";
		String from = "01-04-2020";
		String to = "31-03-2021";

		
		Statement stmt = conn.createStatement();
		stmt = conn.createStatement();
		
		
		//Getting Additional Data for closing account
		String query = "Select AG.ShowIn\n"
				+ "From Account as A JOIN AccountGroup as AG ON (AG.AccountGroupId = A.AccountGroupId)\n"
				+ "JOIN Company as C ON (C.CompanyID = AG.CompanyId)\n"
				+ "Where C.CompanyName = '" + company +"' AND A.AccountName = '"+ accountName +"';";
		ResultSet rs = stmt.executeQuery(query);
		rs.next();
		String showIn = rs.getString("ShowIn");
		
		if(showIn.compareTo("Balance Sheet") == 0)
			showIn = "Balance c/d";
		

		query = "Select FT.TransactionNumber, FT.TransactionDate, A.AccountName, getAmount(FT.TransactionNumber, A.AccountName, '"+ accountName +"') as \"Amount\", (\n"
				+ "				Case \n"
				+ "					When AG.Header = True AND F.Amount > 0 THEN True\n"
				+ "					When AG.Header = True AND F.Amount < 0 THEN False\n"
				+ "					When AG.Header = False AND F.Amount > 0 THEN False\n"
				+ "					When AG.Header = False AND F.Amount < 0 THEN True\n"
				+ "				END\n"
				+ "			) AS \"Header\"\n"
				+ "			From FinancialTransaction as FT JOIN FinancialTransactionEntry as F ON (FT.TransactionNumber =\n"
				+ "			F.TransactionNumber)\n"
				+ "			JOIN Account as A ON(F.AccountId=A.AccountId)\n"
				+ "			JOIN AccountGroup as AG ON (AG.AccountGroupId = A.AccountGroupId)\n"
				+ "			JOIN Company as C ON (C.CompanyID = AG.CompanyId)\n"
				+ "			JOIN (\n"
				+ "				Select (\n"
				+ "					Case \n"
				+ "						When AG.Header = True AND F.Amount > 0 THEN True\n"
				+ "						When AG.Header = True AND F.Amount < 0 THEN False\n"
				+ "						When AG.Header = False AND F.Amount > 0 THEN False\n"
				+ "						When AG.Header = False AND F.Amount < 0 THEN True\n"
				+ "					END\n"
				+ "				) AS Header, FT.TransactionNumber, F.Amount\n"
				+ "				From  FinancialTransaction as FT \n"
				+ "				JOIN FinancialTransactionEntry as F ON (FT.TransactionNumber = F.TransactionNumber) \n"
				+ "				JOIN Account as A ON(F.AccountId=A.AccountId)\n"
				+ "				JOIN AccountGroup as AG ON (AG.AccountGroupId = A.AccountGroupId)\n"
				+ "				Where A.AccountName = '"+ accountName +"' AND ((AG.ShowIn = 'Balance Sheet' AND FT.TransactionDate <= '"+ to +"') OR (AG.ShowIn <> 'Balance Sheet' AND FT.TransactionDate BETWEEN '"+ from +"' AND '"+ to +"')) \n"
				+ "				) as acc ON (acc.TransactionNumber = F.TransactionNumber)\n"
				+ "				Where C.CompanyName = '"+ company +"' AND A.AccountName <> '"+ accountName +"'\n"
				+ "				AND acc.Header <> (\n"
				+ "				Case \n"
				+ "					When AG.Header = True AND F.Amount > 0 THEN True\n"
				+ "					When AG.Header = True AND F.Amount < 0 THEN False\n"
				+ "					When AG.Header = False AND F.Amount > 0 THEN False\n"
				+ "					When AG.Header = False AND F.Amount < 0 THEN True\n"
				+ "				END\n"
				+ "			)\n"
				+ "			Order By FT.TransactionDate, FT.TransactionNumber;";

		System.out.println(query);


		rs = stmt.executeQuery(query);
		LedgerAccount account = new LedgerAccount(accountName);
		long drSide=0, crSide=0;
		Date fromDate = new SimpleDateFormat(dateFormat).parse(from);  

		
		while (rs.next()) {
			//If the account is shown in Balance Sheet	
			if(showIn.compareTo("Balance c/d") == 0 &&  rs.getDate("TransactionDate").before(fromDate)) {
				if(!rs.getBoolean("Header"))
					drSide += rs.getLong("Amount");
				else
					crSide += rs.getLong("Amount");
			}
			else if(!rs.getBoolean("Header")) {
				account.crAccounts.add(new Entry(rs.getDate("TransactionDate"), rs.getString("AccountName"), rs.getDouble("Amount")));
				account.crTotal += rs.getLong("Amount");
			}
			else {
				account.drAccounts.add(new Entry(rs.getDate("TransactionDate"), rs.getString("AccountName"), rs.getDouble("Amount")));
				account.drTotal += rs.getLong("Amount");				
			}
		}
		rs.close();
		stmt.close();
		
		Date toDate = new SimpleDateFormat(dateFormat).parse(to); 
		
		if(drSide > crSide) {
			account.crAccounts.add(0, new Entry(fromDate, "Balance b/d", drSide-crSide));
			account.crTotal += drSide-crSide;
		}
		else if(drSide < crSide) {
			account.drAccounts.add(0, new Entry(fromDate, "Balance b/d", crSide-drSide));
			account.drTotal += crSide-drSide;
		}
		
		if(account.crTotal < account.drTotal) {
			account.crAccounts.add(new Entry(toDate, showIn, account.drTotal-account.crTotal));
			account.crTotal +=  account.drTotal-account.crTotal;
		}
		else {
			account.drAccounts.add(new Entry(toDate, showIn, account.crTotal-account.drTotal));
			account.drTotal +=  account.crTotal-account.drTotal;
		}
		
		
		CreateHTML f1 = new CreateHTML("./Reports/Ledger.html");
		f1.createLedgerAccount(account);
	}
	
	
	public static void Query15() throws SQLException, Exception{
		
		String dateFormat = "dd-MM-yyyy";

		//Query Conditions
		String company = "Myntra";
		String from = "01-04-2020";
		String to = "31-03-2021";
		
		
		Statement stmt = conn.createStatement();
		stmt = conn.createStatement();

		String query = "Select * FROM LedgerOfAllAccounts('"+ company +"', '"+ from +"', '"+ to +"') Order By Name, TransactionDate;";
		ResultSet rs = stmt.executeQuery(query);
		
		System.out.println(query);

		
		long drSide=0, crSide=0;
		Date fromDate = new SimpleDateFormat(dateFormat).parse(from);  
		Date toDate = new SimpleDateFormat(dateFormat).parse(to); 
		Hashtable<String, LedgerAccount> accounts = new Hashtable<String, LedgerAccount>();
		String previousAccount = "", showIn = "";
		
		while (rs.next()) {
			if (!accounts.containsKey(rs.getString("Name"))) {
				if (accounts.size() > 0) {
					LedgerAccount account = accounts.get(previousAccount);
					if (drSide > crSide) {
						account.crAccounts.add(0, new Entry(fromDate, "Balance b/d", drSide - crSide));
						account.crTotal += drSide - crSide;
					} else if (drSide < crSide) {
						account.drAccounts.add(0, new Entry(fromDate, "Balance b/d", crSide - drSide));
						account.drTotal += crSide - drSide;
					}

					drSide = crSide = 0;
				}

				accounts.put(rs.getString("Name"), new LedgerAccount(rs.getString("Name"), rs.getString("ShowIn")));
				previousAccount = rs.getString("Name");
				showIn = rs.getString("ShowIn");
			}

			// If the account is shown in Balance Sheet
			if (showIn.compareTo("Balance Sheet") == 0 && rs.getDate("TransactionDate").before(fromDate)) {
				if (!rs.getBoolean("Header"))
					drSide += rs.getLong("Amount");
				else
					crSide += rs.getLong("Amount");
			} else if (!rs.getBoolean("Header")) {
				accounts.get(rs.getString("Name")).crAccounts.add(
						new Entry(rs.getDate("TransactionDate"), rs.getString("AccountName"), rs.getDouble("Amount")));
				accounts.get(rs.getString("Name")).crTotal += rs.getLong("Amount");
			} else {
				accounts.get(rs.getString("Name")).drAccounts.add(
						new Entry(rs.getDate("TransactionDate"), rs.getString("AccountName"), rs.getDouble("Amount")));
				accounts.get(rs.getString("Name")).drTotal += rs.getLong("Amount");
			}
		}
		
		accounts.forEach((k, account) -> {
			if (account.crTotal < account.drTotal) {
				account.crAccounts.add(new Entry(toDate, account.showIn, account.drTotal - account.crTotal));
				account.crTotal += account.drTotal - account.crTotal;
			} else {
				account.drAccounts.add(new Entry(toDate, account.showIn, account.crTotal - account.drTotal));
				account.drTotal += account.crTotal - account.drTotal;
			}
		});
		
//		Iterator<String> it = accounts.keySet().iterator();
//		
//		while(it.hasNext()) {
//			System.out.println(it.next());
//		}
//		System.out.println(accounts.size());

		CreateHTML f1 = new CreateHTML("./Reports/LedgerAllAccounts.html");
		f1.createLedger(company, accounts);
	}
	
	
	public static void Query21() throws SQLException, Exception {

		String dateFormat = "dd-MM-yyyy";

		// Query Conditions
		String company = "Myntra";
		String from = "01-04-2020";
		String to = "31-03-2021";

		Statement stmt = conn.createStatement();
		stmt = conn.createStatement();

		String query = "Select AG.ShowIn, A.AccountName, ABS(SUM(F.Amount)) as Amount, (\n"
				+ "	Case\n"
				+ "		WHEN SUM(F.Amount) < 0 THEN NOT AG.Header\n"
				+ "		ELSE AG.Header\n"
				+ "	END\n"
				+ ") as \"Header\"\n"
				+ "From FinancialTransaction as FT JOIN FinancialTransactionEntry as F ON (FT.TransactionNumber =\n"
				+ "F.TransactionNumber)\n"
				+ "JOIN Account as A ON(F.AccountId=A.AccountId)\n"
				+ "JOIN AccountGroup as AG ON (AG.AccountGroupId = A.AccountGroupId)\n"
				+ "JOIN Company as C ON (C.CompanyID = AG.CompanyId)\n"
				+ "Where C.CompanyName = '"+ company +"' AND AG.Name <> 'Capital'\n"
				+ "AND ((AG.ShowIn = 'Balance Sheet' AND FT.TransactionDate <= '"+ to +"') OR (AG.ShowIn <> 'Balance Sheet' AND FT.TransactionDate BETWEEN '"+ from +"' AND '"+ to +"'))\n"
				+ "Group By ShowIn, A.AccountName, AG.Header\n"
				+ "UNION \n"
				+ "--To add all previuous year profit or loss to captial account\n"
				+ "Select r1.ShowIn, r1.AccountName, coalesce((\"Amount\" +\"Net Profit\"), \"Amount\"), r1.Header\n"
				+ "FROM (\n"
				+ "	Select AG.ShowIn, A.AccountName, SUM(F.Amount) as \"Amount\", AG.Header\n"
				+ "	From FinancialTransaction as FT JOIN FinancialTransactionEntry as F ON (FT.TransactionNumber = F.TransactionNumber)\n"
				+ "	JOIN Account as A ON(F.AccountId=A.AccountId) \n"
				+ "	JOIN AccountGroup as AG ON (AG.AccountGroupId = A.AccountGroupId) \n"
				+ "	JOIN Company as C ON (C.CompanyID = AG.CompanyId)\n"
				+ "	Where C.CompanyName = '"+ company +"' AND AG.Name = 'Capital' \n"
				+ "	Group By AG.ShowIn, AG.Header, A.AccountName\n"
				+ "	) as r1 FULL JOIN \n"
				+ "	(\n"
				+ "		Select DrTable.CompanyID,DrTable.CompanyName,(CrSide - DrSide) as \"Net Profit\"\n"
				+ "		From\n"
				+ "		(\n"
				+ "				Select coalesce(SUM(F.Amount),0) as DrSide,C.CompanyID,C.CompanyName \n"
				+ "				From FinancialTransaction as FT JOIN FinancialTransactionEntry as F ON (FT.TransactionNumber = F.TransactionNumber)\n"
				+ "				JOIN Account as A ON(F.AccountId=A.AccountId) \n"
				+ "				JOIN AccountGroup as AG ON (AG.AccountGroupId = A.AccountGroupId)\n"
				+ "				JOIN Company as C ON (C.CompanyID = AG.CompanyId)\n"
				+ "				Where C.CompanyName = '"+ company +"' \n"
				+ "				AND (AG.ShowIn = 'Profit and Loss Account' OR AG.ShowIn = 'Trading Account')  \n"
				+ "				AND AG.Header = True\n"
				+ "				AND FT.TransactionDate < '"+ from +"' \n"
				+ "				Group by C.CompanyID\n"
				+ "		) as DrTable JOIN\n"
				+ "		(\n"
				+ "				Select coalesce(SUM(F.Amount),0) as CrSide, C.CompanyID,C.CompanyName  \n"
				+ "				From FinancialTransaction as FT JOIN FinancialTransactionEntry as F ON (FT.TransactionNumber = F.TransactionNumber)\n"
				+ "				JOIN Account as A ON(F.AccountId=A.AccountId) \n"
				+ "				JOIN AccountGroup as AG ON (AG.AccountGroupId = A.AccountGroupId) \n"
				+ "				JOIN Company as C ON (C.CompanyID = AG.CompanyId)\n"
				+ "				Where C.CompanyName = '"+ company +"' \n"
				+ "				AND (AG.ShowIn = 'Profit and Loss Account' OR AG.ShowIn = 'Trading Account') \n"
				+ "				AND AG.Header = False\n"
				+ "				AND FT.TransactionDate < '"+ from +"' \n"
				+ "				Group by C.CompanyID\n"
				+ "		) as CrTable\n"
				+ "		ON DrTable.CompanyID=CrTable.CompanyID\n"
				+ "	)as r2 ON TRUE;";
		ResultSet rs = stmt.executeQuery(query);

		System.out.println(query);
		
		Hashtable<String, LedgerAccount> finalAccounts = new Hashtable<String, LedgerAccount>();
		
		finalAccounts.put("Trading Account", new LedgerAccount("Trading Account"));
		finalAccounts.put("Profit and Loss Account", new LedgerAccount("Profit and Loss Account"));
		finalAccounts.put("Balance Sheet", new LedgerAccount("Balance Sheet"));
		
		while(rs.next()) {
			if (rs.getBoolean("Header")) {
				finalAccounts.get(rs.getString("ShowIn")).crAccounts.add(
						new Entry(null, rs.getString("AccountName"), rs.getDouble("Amount")));
				finalAccounts.get(rs.getString("ShowIn")).crTotal += rs.getLong("Amount");
			} else {
				finalAccounts.get(rs.getString("ShowIn")).drAccounts.add(
						new Entry(null, rs.getString("AccountName"), rs.getDouble("Amount")));
				finalAccounts.get(rs.getString("ShowIn")).drTotal += rs.getLong("Amount");
			}
		}
		
		//System.out.println("Gross Profit: " + (finalAccounts.get("Trading Account").crTotal - finalAccounts.get("Trading Account").drTotal) );
		//System.out.println("Net Profit: " + (finalAccounts.get("Profit and Loss Account").crTotal - finalAccounts.get("Profit and Loss Account").drTotal + (finalAccounts.get("Trading Account").crTotal - finalAccounts.get("Trading Account").drTotal)) );

		
		long grossProfit = (finalAccounts.get("Trading Account").drTotal - finalAccounts.get("Trading Account").crTotal);
//		System.out.println("Gross Profit: " + grossProfit);
		if(grossProfit < 0) {
			finalAccounts.get("Trading Account").drAccounts.add(
					new Entry(null, "Gross Loss", (-grossProfit)));
			finalAccounts.get("Trading Account").drTotal += (-grossProfit);
			
			//Transferring Gross Loss to P&L
			finalAccounts.get("Profit and Loss Account").crAccounts.add(
					new Entry(null, "Gross Loss", (-grossProfit)));
			finalAccounts.get("Profit and Loss Account").crTotal += (-grossProfit);
		}
		else {
			finalAccounts.get("Trading Account").crAccounts.add(
					new Entry(null, "Gross Profit", grossProfit ));
			finalAccounts.get("Trading Account").crTotal += grossProfit;

			//Transferring Gross Profit to P&L
			finalAccounts.get("Profit and Loss Account").drAccounts.add(
					new Entry(null, "Gross Profit", grossProfit));
			finalAccounts.get("Profit and Loss Account").drTotal += grossProfit;
		}
		
		
		long netProfit = (finalAccounts.get("Profit and Loss Account").drTotal - finalAccounts.get("Profit and Loss Account").crTotal);
		if(netProfit < 0) {
			finalAccounts.get("Profit and Loss Account").drAccounts.add(
					new Entry(null, "Net Loss", (-netProfit)));
			finalAccounts.get("Profit and Loss Account").drTotal += (-netProfit);
			
			//Transferring Gross Loss to P&L
			finalAccounts.get("Balance Sheet").crAccounts.add(
					new Entry(null, "Net Loss", (-netProfit)));
			finalAccounts.get("Balance Sheet").crTotal += (-netProfit);
		}
		else {
			finalAccounts.get("Profit and Loss Account").crAccounts.add(
					new Entry(null, "Net Profit", netProfit ));
			finalAccounts.get("Profit and Loss Account").crTotal += netProfit;

			//Transferring Gross Profit to P&L
			finalAccounts.get("Balance Sheet").drAccounts.add(
					new Entry(null, "Net Profit", netProfit));
			finalAccounts.get("Balance Sheet").drTotal += netProfit;
		}
		
		
		CreateHTML f1 = new CreateHTML("./Reports/FinalStatements.html");
		f1.createFinalStatements(company, finalAccounts, from, to);
	}
	

	public static void Query6()throws SQLException {
		String company = "Myntra";
		String InvoiceId = "1";
		
		Statement stmt = conn.createStatement();
		stmt = conn.createStatement();

		String query = "\n"
				+"Select C.CompanyName,A.AccountName ,Si.InvoiceId,Si.Date,It.ItemName,I.Amount,I.Qty\n"
				+"From SalesInvoice as Si\n"
				+"JOIN Account as A ON ( Si.AccountId = A.AccountId )\n"
				+"JOIN Company as C ON (C.CompanyID = Si.CompanyId)\n"
				+"JOIN SalesItem as I ON (Si.InvoiceId = I.InvoiceId and Si. CompanyId=I. CompanyId)\n"
				+"JOIN Item as It ON ( I.ItemID = It.ItemID )\n"
				+"Where C.CompanyName = '"+ company +"' AND Si.InvoiceId="+ InvoiceId +";";
		System.out.println(query);
		ResultSet rs = stmt.executeQuery(query);

		
		
		rs.next();
		InvoiceEntry items = new InvoiceEntry(rs.getInt("InvoiceID"), rs.getDate("Date"), rs.getString("AccountName"));
		items.items.add(new Item(rs.getString("ItemName"),(rs.getDouble("Amount")*rs.getInt("Qty")),rs.getInt("Qty")));
		
		while (rs.next()) {
			items.items.add(new Item(rs.getString("ItemName"),(rs.getDouble("Amount")*rs.getInt("Qty")),rs.getInt("Qty")));
		}
		rs.close();
		stmt.close();
		
		CreateHTML f1 = new CreateHTML("./Reports/Bill.html");
		f1.createInvoice("Myntra", items);
	}
	

	public static void main(String[] args) throws SQLException, Exception{		
		//Not Required For Java 8
//		Class.forName("org.postgresql.Driver");
		conn = DriverManager.getConnection("jdbc:postgresql://127.0.0.1:5432/"+DATABASE, USERNAME, PASSWORD);
		
		
		Statement stmt = conn.createStatement();

		stmt = conn.createStatement();
		String sql = "SET search_path TO AccountingSystem,public;SET DATESTYLE TO European;\n";
		stmt.executeUpdate(sql);
		stmt.close();
		System.out.println("Changed Search Path successfully");

		
		//Uncomment Function Call to execute Corresponding Query
//		Query6();	// Generate Bill Of a Particular Invoice Number
//		Query13();	// Displays all the Journal Entry of a given Company for a given time
//		Query14();	//Display given account of a Given Company for a given time
//		Query15();	//Display all the accounts of a Given Company for a given time
		Query21();	//Display The final Statements of a company i.e. Trading, Profit and Loss and Balance Sheet

		
		conn.close();
	}

}
