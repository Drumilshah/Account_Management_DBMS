public class Account {
	String accountName;
	double amount;
	
	public Account(String accountName, double amount) {
		this.accountName = accountName;
		this.amount = amount;
	}
	
	public String toString() {
		return this.accountName + "\t" + this.amount;
	}
}
