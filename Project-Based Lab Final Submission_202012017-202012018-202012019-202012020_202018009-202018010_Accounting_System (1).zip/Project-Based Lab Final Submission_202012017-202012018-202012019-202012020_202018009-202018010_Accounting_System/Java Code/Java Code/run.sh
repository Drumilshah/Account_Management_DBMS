javac AccountingSemProject.java
java -cp "postgresql-42.2.18.jar:" AccountingSemProject