import java.awt.Desktop;
import java.io.*;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Locale;


/***********************************************************
 * 	{companyNameHolder} -> Company Name
 * 	{TotalAmount}		-> Total Amount
 * 	{JournalEntryData}	-> Journal Rows
 * 	{LedgerData}		-> Ledger Rows
 * 
 * 	-------- Journal Entry --------
 * 	{numberOfLine}	->	Number of Accounts + 1
 * 	{date}			->	Date
 * 	{debitAccount}	-> 	Debit Account
 * 	{debitAmount}	->	Debit Amount
 * 	{creditAccount}	->	Credit Account
 * 	{creditAmount}	-> 	Credit Amount
 * 	{description}	->	Transaction Description
 * 
 * 
 *	-------- Ledger Account --------
 *	{drDate}		->	Date of Debit Account
 *	{drAccount}		->	Debit Account Name		
 *	{drAmount}		->	Debit Amount
 * 	{crDate}		->	Date of Credit Account
 *	{crAccount}		->	Credit Account Name		
 *	{crAmount}		->	Credit Amount
 * 
 ***********************************************************/

public class CreateHTML {
	File htmlFile;
	String destination = "/Reports/temp.html";
	String dateFormat = "MMM. dd, yyyy";
	
	public CreateHTML(String destination) {
		this.destination = destination;
	}
	
	public String format(double value) {
	    if(value < 1000) {
	        return format("###", value);
	    } else {
	        double hundreds = value % 1000;
	        int other = (int) (value / 1000);
	        return format(",##", other) + ',' + format("000", hundreds);
	    }
	}
	
	public String format(long value) {
	    if(value < 1000) {
	        return format("###", value);
	    } else {
	        long hundreds = value % 1000;
	        int other = (int) (value / 1000);
	        return format(",##", other) + ',' + format("000", hundreds);
	    }
	}

	private String format(String pattern, Object value) {
	    return new DecimalFormat(pattern).format(value);
	}
	
	public void createJournal(String companyName, ArrayList<JournalEntry> entries){
		try {
			//Loading Journal Template
			String template = "./templates/JournalEntry.html";
			String initialEntry = "            <tr>\n"
					+ "                <td class=\"date\" rowspan=\"{numberOfLine}\">{date}</td>\n"
					+ "                <td class=\"particulars\">\n"
					+ "                    {debitAccount} A/c<span class=\"debit\"> Dr.</span></td>\n"
					+ "                <td class=\"lf\"></td>\n"
					+ "                <td class=\"dr\">{debitAmount}</td>\n"
					+ "                <td class=\"cr\"></td>\n"
					+ "            </tr>\n"
					+ "";
			
			String drAccountTemplate = "            <tr>\n"
					+ "                <td class=\"particulars\">\n"
					+ "                    {debitAccount} A/c<span class=\"debit\"> Dr.</span></td>\n"
					+ "                <td class=\"lf\"></td>\n"
					+ "                <td class=\"dr\">{debitAmount}</td>\n"
					+ "                <td class=\"cr\"></td>\n"
					+ "            </tr>\n"
					+ "";
			
			String crAccountTemplate = "            <tr>\n"
					+ "                <td class=\"particulars\">\n"
					+ "                    <span class=\"credit\"> To {creditAccount} A/c</span></td>\n"
					+ "                <td class=\"lf\"></td>\n"
					+ "                <td class=\"dr\"></td>\n"
					+ "                <td class=\"cr\">{creditAmount}</td>\n"
					+ "            </tr>";
			
			
			String descriptionTemplate = "            <tr>\n"
					+ "                <td class=\"desc\">(Being {description})</td>\n"
					+ "                <td class=\"lf\"></td>\n"
					+ "                <td class=\"dr\"></td>\n"
					+ "                <td class=\"cr\"></td>\n"
					+ "            </tr>\n"
					+ "";
			
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(template), "UTF-8"));
		
			StringBuilder htmlCode = new StringBuilder();

			//Reading Template
			char []buffer = new char[10];
			while(in.read(buffer) != -1) {
				htmlCode.append(new String(buffer));
				buffer = new char[10];
			}
			in.close();
			
			//Creating HTML File for Journal Entry
			String code = htmlCode.toString();
			code = code.replace("{companyNameHolder}", companyName);
			
			
			//Making Entries
			StringBuilder journalEntryCode = new StringBuilder();
			SimpleDateFormat f = new SimpleDateFormat(this.dateFormat);
			
			JournalEntry entry;			
			long total = 0;
			Iterator<JournalEntry> it = entries.iterator();
			
			while(it.hasNext()) {
				entry = it.next();
				
				Iterator<Account> jt = entry.drAccounts.iterator();
				
				//Initial Account
				Account acc = jt.next();
				total += acc.amount; 
				journalEntryCode.append(
					initialEntry.replace("{date}", f.format(entry.date)).replace(
							"{numberOfLine}", Integer.toString((entry.drAccounts.size() + entry.crAccounts.size() +1))).replace(
								"{debitAccount}",acc.accountName).replace(
										"{debitAmount}", this.format(acc.amount))
				);
				
				
				//Additional Debit Accounts
				while(jt.hasNext()){
					acc = jt.next();
					total += acc.amount;
					journalEntryCode.append(
							drAccountTemplate.replace("{debitAccount}",acc.accountName).replace(
									"{debitAmount}",  this.format(acc.amount))
						);
				}
				
				
				//Adding Credit Accounts
				jt = entry.crAccounts.iterator();
				
				while(jt.hasNext()){
					acc = jt.next();
					total += acc.amount;
					journalEntryCode.append(
							crAccountTemplate.replace("{creditAccount}",acc.accountName).replace(
									"{creditAmount}", this.format(acc.amount))
						);
				}
				
				//Adding Description
				journalEntryCode.append(
						descriptionTemplate.replace("{description}", entry.description)
					);
			}
						
			//Adding Journal Entries to main code
			code = code.replace("{JournalEntryData}", journalEntryCode).replace("{TotalAmount}", this.format(total));

			
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(this.destination), "UTF-8"));
			
			out.write(code);
			out.close();
			
			htmlFile = new File(this.destination);
			Desktop.getDesktop().browse(htmlFile.toURI());
		}
		catch(FileNotFoundException e) {
			System.out.println("\n\n\nTemplate doesn't exist");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void createLedgerAccount(LedgerAccount account) {
		try {
			//Templates
			String template = "./templates/LedgerAccount.html";
			String ledgerRow = "                <tr>\n"
					+ "                    <td class=\"date\">{crDate}</td>\n"
					+ "                    <td class=\"particulars\">To {crAccount} A/c</td>\n"
					+ "                    <td class=\"jf\"></td>\n"
					+ "                    <td class=\"dr\">{crAmount}</td>\n"
					+ "                    <td class=\"date\">{drDate}</td>\n"
					+ "                    <td class=\"particulars\">By {drAccount} A/c</td>\n"
					+ "                    <td class=\"jf\"></td>\n"
					+ "                    <td class=\"cr\">{drAmount}</td>\n"
					+ "                </tr>\n";
		
			
			
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(template), "UTF-8"));
			
			StringBuilder htmlCode = new StringBuilder();
	
			//Reading Template
			char []buffer = new char[10];
			while(in.read(buffer) != -1) {
				htmlCode.append(new String(buffer));
				buffer = new char[10];
			}
			in.close();
			
			//Creating HTML File for Journal Entry
			String code = htmlCode.toString();
			code = code.replace(
				"{accountName}", account.accountName).replace(
					"{TotalAmount}", this.format(account.crTotal)
						);
			

			
			//Making Entries
			StringBuilder ledgerEntryCode = new StringBuilder();
			SimpleDateFormat f = new SimpleDateFormat(this.dateFormat);
			String temp;
			
			int size = account.crAccounts.size();
			if(account.crAccounts.size() < account.drAccounts.size())
				size = account.drAccounts.size();
			
			for(int i=0; i<size; i++) {
				temp = ledgerRow;
				if(i<account.crAccounts.size()) {
					temp = temp.replace(
						"{crDate}", f.format(account.crAccounts.get(i).date) ).replace(
								"{crAccount}" , account.crAccounts.get(i).accountName).replace(
										"{crAmount}" , this.format(account.crAccounts.get(i).amount)
								);
				}
				else
					temp = temp.replace("{crDate}", "" ).replace("To {crAccount} A/c" , "").replace("{crAmount}" , "");
				
				
				if(i<account.drAccounts.size()) {
					temp = temp.replace(
							"{drDate}", f.format(account.drAccounts.get(i).date) ).replace(
									"{drAccount}" , account.drAccounts.get(i).accountName).replace(
											"{drAmount}" , this.format(account.drAccounts.get(i).amount)
									);
				}
				else
					temp = temp.replace("{drDate}", "" ).replace("By {drAccount} A/c" , "").replace("{drAmount}" , "");
					
				
				ledgerEntryCode.append(temp);
			}
			
			//Adding Journal Entries to main code
			code = code.replace("{LedgerData}", ledgerEntryCode).replace("Balance c/d A/c" , "Balance c/d").replace("Balance b/d A/c" , "Balance b/d");

			
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(this.destination), "UTF-8"));
			
			out.write(code);
			out.close();
			
			htmlFile = new File(this.destination);
			Desktop.getDesktop().browse(htmlFile.toURI());
			
		}
		catch(FileNotFoundException e) {
			System.out.println("\n\n\nTemplate doesn't exist");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	public void createLedger(String companyName, Hashtable<String, LedgerAccount> accounts) {
		try {
			//Templates
			String template = "./templates/LedgerAccounts.html";
			
			String ledgerTable = "<div class=\"accountInfo\">\n"
					+ "            <div class=\"accountName\">\n"
					+ "                {accountName} Account\n"
					+ "            </div>\n"
					+ "        </div>\n"
					+ "        <span class=\"debit\">Dr.</span>\n"
					+ "        <span class=\"credit\">Cr.</span>\n"
					+ "\n"
					+ "        <br>\n"
					+ "        <div class=\"ledgerTable\">\n"
					+ "            <table>\n"
					+ "                <tr class=\"header\">\n"
					+ "                    <th class=\"date\">Date</th>\n"
					+ "                    <th class=\"particulars\">Particulars</th>\n"
					+ "                    <th class=\"jf\">J.F.</th>\n"
					+ "                    <th>Amount(₹)</th>\n"
					+ "                    <th class=\"date\">Date</th>\n"
					+ "                    <th class=\"particulars\">Particulars</th>\n"
					+ "                    <th class=\"jf\">J.F.</th>\n"
					+ "                    <th>Amount(₹)</th>\n"
					+ "                </tr>\n"
					+ "				{LedgerData}\n"
					+ "                <tr>\n"
					+ "                    <td class=\"date\"></td>\n"
					+ "                    <td class=\"particulars\"></td>\n"
					+ "                    <td class=\"jf\"></td>\n"
					+ "                    <td class=\"finalAmount\">{TotalAmount}</td>\n"
					+ "                    <td class=\"date\"></td>\n"
					+ "                    <td class=\"particulars\"></td>\n"
					+ "                    <td class=\"jf\"></td>\n"
					+ "                    <td class=\"finalAmount\">{TotalAmount}</td>\n"
					+ "                </tr>\n"
					+ "            </table>\n"
					+ "        </div>"
					+ "		   <br><br>";
			
			String ledgerRow = "                <tr>\n"
					+ "                    <td class=\"date\">{crDate}</td>\n"
					+ "                    <td class=\"particulars\">To {crAccount} A/c</td>\n"
					+ "                    <td class=\"jf\"></td>\n"
					+ "                    <td class=\"dr\">{crAmount}</td>\n"
					+ "                    <td class=\"date\">{drDate}</td>\n"
					+ "                    <td class=\"particulars\">By {drAccount} A/c</td>\n"
					+ "                    <td class=\"jf\"></td>\n"
					+ "                    <td class=\"cr\">{drAmount}</td>\n"
					+ "                </tr>\n";
			
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(template), "UTF-8"));
			
			StringBuilder htmlCode = new StringBuilder();
	
			//Reading Template
			char []buffer = new char[10];
			while(in.read(buffer) != -1) {
				htmlCode.append(new String(buffer));
				buffer = new char[10];
			}
			in.close();
			
			StringBuilder LedgerHTMLString = new StringBuilder();

			accounts.forEach((key, account) -> {
				// Creating HTML File for Journal Entry
				String code = ledgerTable;
				code = code.replace("{accountName}", account.accountName).replace("{TotalAmount}",
						this.format(account.crTotal));

				// Making Entries
				StringBuilder ledgerEntryCode = new StringBuilder();
				SimpleDateFormat f = new SimpleDateFormat(this.dateFormat);
				String temp;

				int size = account.crAccounts.size();
				if (account.crAccounts.size() < account.drAccounts.size())
					size = account.drAccounts.size();

				for (int i = 0; i < size; i++) {
					temp = ledgerRow;
					if (i < account.crAccounts.size()) {
						temp = temp.replace("{crDate}", f.format(account.crAccounts.get(i).date))
								.replace("{crAccount}", account.crAccounts.get(i).accountName)
								.replace("{crAmount}", this.format(account.crAccounts.get(i).amount));
					} else
						temp = temp.replace("{crDate}", "").replace("To {crAccount} A/c", "").replace("{crAmount}", "");

					if (i < account.drAccounts.size()) {
						temp = temp.replace("{drDate}", f.format(account.drAccounts.get(i).date))
								.replace("{drAccount}", account.drAccounts.get(i).accountName)
								.replace("{drAmount}", this.format(account.drAccounts.get(i).amount));
					} else
						temp = temp.replace("{drDate}", "").replace("By {drAccount} A/c", "").replace("{drAmount}", "");

					ledgerEntryCode.append(temp);
				}

				// Adding Journal Entries to main code
				LedgerHTMLString.append(code.replace(
						"{LedgerData}", ledgerEntryCode).replace(
								"Balance Sheet A/c", "Balance c/d").replace(
										"Balance b/d A/c", "Balance b/d")
						);
			});
			
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(this.destination), "UTF-8"));
			
			out.write(htmlCode.toString().replace(
					"{AccountTables}", LedgerHTMLString.toString()).replace(
							"{companyNameHolder}", companyName)
					);
			out.close();
			
			htmlFile = new File(this.destination);
			Desktop.getDesktop().browse(htmlFile.toURI());
			
		}
		catch(FileNotFoundException e) {
			System.out.println("\n\n\nTemplate doesn't exist");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	public void createFinalStatements(String companyName, Hashtable<String, LedgerAccount> accounts, String fromDate, String toDate) {
		try {
			//Templates
			String template = "./templates/FinalStatements.html";
			
			String ledgerRow = "      <tr>\n"
					+ "                    <td class=\"particulars\">To {crAccount} A/c</td>\n"
					+ "                    <td class=\"dr\">{crAmount}</td>\n"
					+ "                    <td class=\"particulars\">By {drAccount} A/c</td>\n"
					+ "                    <td class=\"cr\">{drAmount}</td>\n"
					+ "                </tr>\n";
			
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(template), "UTF-8"));
			
			StringBuilder htmlCode = new StringBuilder();
	
			//Reading Template
			char []buffer = new char[10];
			while(in.read(buffer) != -1) {
				htmlCode.append(new String(buffer));
				buffer = new char[10];
			}
			in.close();
			
			
			StringBuilder ledgerEntryCode[] = new StringBuilder[3];

			String[] finalAccounts = {
					"Trading Account", "Profit and Loss Account", "Balance Sheet"
			};

			for(int i=0; i<2; i++) {
				LedgerAccount account = accounts.get(finalAccounts[i]);
				
				// Making Entries
				String temp;
				ledgerEntryCode[i] = new StringBuilder();

				int size = account.crAccounts.size();
				if (account.crAccounts.size() < account.drAccounts.size())
					size = account.drAccounts.size();

				for (int j = 0; j < size; j++) {
					temp = ledgerRow;
					if (j < account.crAccounts.size()) {
						temp = temp.replace("{crAccount}", account.crAccounts.get(j).accountName)
								.replace("{crAmount}", this.format(account.crAccounts.get(j).amount));
					} else
						temp = temp.replace("To {crAccount} A/c", "").replace("{crAmount}", "");

					if (j < account.drAccounts.size()) {
						temp = temp.replace("{drAccount}", account.drAccounts.get(j).accountName)
								.replace("{drAmount}", this.format(account.drAccounts.get(j).amount));
					}else
						temp = temp.replace("By {drAccount} A/c", "").replace("{drAmount}", "");

					ledgerEntryCode[i].append(temp);
				}
			}
			
			
			//Balance Sheet
			ledgerRow = "      <tr>\n"
					+ "                    <td class=\"particulars\">{drAccount} A/c</td>\n"
					+ "                    <td class=\"dr\">{drAmount}</td>\n"
					+ "                    <td class=\"particulars\">{crAccount} A/c</td>\n"
					+ "                    <td class=\"cr\">{crAmount}</td>\n"
					+ "                </tr>\n";
			
			LedgerAccount account = accounts.get(finalAccounts[2]);
			String temp;
			ledgerEntryCode[2] = new StringBuilder();

			int size = account.crAccounts.size();
			if (account.crAccounts.size() < account.drAccounts.size())
				size = account.drAccounts.size();

			for (int j = 0; j < size; j++) {
				temp = ledgerRow;
				if (j < account.crAccounts.size()) {
					temp = temp.replace("{crAccount}", account.crAccounts.get(j).accountName)
							.replace("{crAmount}", this.format(account.crAccounts.get(j).amount));
				} else
					temp = temp.replace("{crAccount} A/c", "").replace("{crAmount}", "");

				if (j < account.drAccounts.size()) {
					temp = temp.replace("{drAccount}", account.drAccounts.get(j).accountName)
							.replace("{drAmount}", this.format(account.drAccounts.get(j).amount));
				}else
					temp = temp.replace("{drAccount} A/c", "").replace("{drAmount}", "");

				ledgerEntryCode[2].append(temp);
			}
			
			
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(this.destination), "UTF-8"));
			
			out.write(htmlCode.toString().replace(
							"{companyNameHolder}", companyName).replace(
									"{fromDate}", fromDate).replace(
											"{toDate}", toDate).replace(
													"{TradingData}", ledgerEntryCode[0].toString()).replace(
															"{P&LData}", ledgerEntryCode[1].toString()).replace(
																	"{BalanceSheetData}", ledgerEntryCode[2].toString()).replace(
																			"{TTotalAmount}", this.format(accounts.get("Trading Account").crTotal)).replace(
																					"{PTotalAmount}", this.format(accounts.get("Profit and Loss Account").crTotal)).replace(
																							"{BTotalAmount}", this.format(accounts.get("Balance Sheet").crTotal))
					);
			out.close();
			
			htmlFile = new File(this.destination);
			Desktop.getDesktop().browse(htmlFile.toURI());
			
		}
		catch(FileNotFoundException e) {
			System.out.println("\n\n\nTemplate doesn't exist");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}


	public void createInvoice(String companyName, InvoiceEntry entry){
		try {
			//Loading Journal Template
			String template = "./templates/Bill.html";
			String itemEntry = "<tr class=\"item\">\n"
					+ "                <td>{ItemName}</td>\n"
					+ "                <td>{Qty}</td>\n"
					+ "                <td>{Amount}</td>\n"
					+ "            </tr>";
						
			
			
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(template), "UTF-8"));
			SimpleDateFormat f = new SimpleDateFormat(this.dateFormat);
			StringBuilder htmlCode = new StringBuilder();

			//Reading Template
			char []buffer = new char[10];
			while(in.read(buffer) != -1) {
				htmlCode.append(new String(buffer));
				buffer = new char[10];
			}
			in.close();
			
			//Creating HTML File for Journal Entry
			String code = htmlCode.toString();
			code = code.replace("{companyNameHolder}", companyName).replace("{Date}",f.format(entry.date));
			
			//Making Entries
			StringBuilder InvoiceEntryCode = new StringBuilder();
			
						
			double total = 0;
			Iterator<Item> it = entry.items.iterator();
			Item itm;
				while(it.hasNext()){
					itm = it.next();
					total += itm.amount;
					InvoiceEntryCode.append(
							itemEntry.replace("{ItemName}",itm.item).replace(
									"{Qty}", Integer.toString(itm.qty)).replace("{Amount}",this.format(itm.amount))
						);
				}
				
			
						
			//Adding Journal Entries to main code
			code = code.replace(
					"{InvoiceNumber}", Integer.toString(entry.invoiceId)).replace(
							"{ItemData}", InvoiceEntryCode).replace("{TotalAmount}", this.format(total)).replace("{AccountName}", entry.accountName
									);

			
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(this.destination), "UTF-8"));
			
			out.write(code);
			out.close();
			
			htmlFile = new File(this.destination);
			Desktop.getDesktop().browse(htmlFile.toURI());
		}
		catch(FileNotFoundException e) {
			System.out.println("\n\n\nTemplate doesn't exist");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
