import java.util.ArrayList;
import java.util.Date;

class Entry extends Account{
	Date date;
	
	public Entry(Date date, String accountName, double amount) {
		super(accountName, amount);
		this.date = date;
	}
}

public class LedgerAccount {
	String accountName;
	ArrayList<Entry> drAccounts;
	ArrayList<Entry> crAccounts;
	String showIn;
	long drTotal;
	long crTotal;
	
	public LedgerAccount() {
		this.drAccounts = new ArrayList<Entry>();
		this.crAccounts = new ArrayList<Entry>();
		this.drTotal=0;
		this.crTotal=0;
	}

	public LedgerAccount(String accountName) {
		this.accountName = accountName;
		this.drAccounts = new ArrayList<Entry>();
		this.crAccounts = new ArrayList<Entry>();
		this.drTotal=0;
		this.crTotal=0;
	}

	public LedgerAccount(String accountName, String showIn) {
		this.accountName = accountName;
		this.showIn = showIn;
		this.drAccounts = new ArrayList<Entry>();
		this.crAccounts = new ArrayList<Entry>();
		this.drTotal=0;
		this.crTotal=0;
	}

}
