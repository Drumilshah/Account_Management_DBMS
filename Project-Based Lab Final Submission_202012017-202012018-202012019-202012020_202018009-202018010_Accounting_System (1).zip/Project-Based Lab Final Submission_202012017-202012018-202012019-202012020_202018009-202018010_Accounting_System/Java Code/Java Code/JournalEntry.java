import java.util.ArrayList;
import java.util.Iterator;
import java.util.Date;

public class JournalEntry{
	Date date;
	ArrayList<Account> drAccounts, crAccounts;
	String description;
	
	public JournalEntry() {
		this.drAccounts = new ArrayList<Account>();
		this.crAccounts = new ArrayList<Account>();
	}
	
	public JournalEntry(Date date, String description) {
		this.date = date;
		this.description = description;
		this.drAccounts = new ArrayList<Account>();
		this.crAccounts = new ArrayList<Account>();
	}
	
	public String toString() {
		StringBuilder output = new StringBuilder();
		
		output.append("\n\nDate: " + this.date);
		
		Iterator<Account> it = this.drAccounts.iterator();
		
		while(it.hasNext())
			output.append("\nDr.\t" + it.next());
		
		it = this.crAccounts.iterator();
		while(it.hasNext())
			output.append("\n\t\tTo " + it.next());

		
		output.append("\n(" + this.description + ")");
		return output.toString();
	}
}